xsim {mult_checked} -autoloadwcfg -runall
