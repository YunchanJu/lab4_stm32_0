set_param general.maxThreads 2
set base {C:/Users/samsung/Documents/Codex/2026-10-19/x20/outputs/STM32_0_보완자료/fpga}
foreach n {mult_4bit bcd_conv} {
 set root [file join $base $n]
 file mkdir "$root/verification"
 create_project -in_memory -part xc7s75fgga484-1
 read_verilog [glob "$root/src/*.v"]
 read_xdc "$root/constraints/pins.xdc"
 synth_design -top $n -part xc7s75fgga484-1
 # Static DIP-to-LED combinational circuit: an explicit 20ns logic-path budget.
 set_max_delay 20.000 -from [all_inputs] -to [all_outputs]
 opt_design
 place_design
 route_design
 report_utilization -file "$root/verification/utilization.rpt"
 report_timing_summary -file "$root/verification/timing.rpt"
 report_drc -file "$root/verification/drc.rpt"
 write_checkpoint -force "$root/verification/routed.dcp"
 write_bitstream -force "$root/$n.bit"
 close_project
 puts "OCT12_BITSTREAM_PASS $n"
}
