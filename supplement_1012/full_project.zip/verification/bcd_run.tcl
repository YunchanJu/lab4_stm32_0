xsim {bcd_checked} -autoloadwcfg -runall
