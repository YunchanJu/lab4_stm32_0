set_param general.maxThreads 2
set root {C:/Users/samsung/Documents/Codex/2026-10-19/x20/outputs/STM32_1_prepare/fpga/piano}
create_project -in_memory -part xc7s75fgga484-1
read_verilog "$root/src/piano.v"
read_verilog "$root/src/piano_board.v"
read_xdc "$root/constraints/piano_board.xdc"
synth_design -top piano_board -part xc7s75fgga484-1
opt_design
place_design
phys_opt_design
route_design
report_timing_summary -file "$root/verification/routed_timing.rpt"
report_drc -file "$root/verification/final_drc.rpt"
report_io -file "$root/verification/final_io.rpt"
report_utilization -file "$root/verification/utilization.rpt"
if {[get_property SLACK [get_timing_paths -delay_type max -max_paths 1]] < 0} {error "Setup timing violation"}
write_checkpoint -force "$root/verification/piano_routed.dcp"
write_bitstream -force "$root/piano_board.bit"
puts PIANO_FINAL_TIMING_AND_BITSTREAM_PASS
