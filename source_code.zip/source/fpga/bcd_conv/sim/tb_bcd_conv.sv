`timescale 1ns/1ps
module tb_bcd_conv;
 reg [3:0] ten,one; wire [6:0] bin; wire valid;
 bcd_conv dut(.one(one),.ten(ten),.bin(bin),.valid(valid));
 integer t,o,good=0,bad=0;
 initial begin
  $dumpfile("bcd_conv.vcd"); $dumpvars(0,tb_bcd_conv);
  for(t=0;t<16;t=t+1) for(o=0;o<16;o=o+1) begin
   ten=t; one=o; #1;
   if(valid !== ((t<10)&&(o<10))) $fatal(1,"BCD valid");
   if(t<10 && o<10) begin
    if(bin !== t*10+o) $fatal(1,"BCD value");
    good=good+1;
   end else bad=bad+1;
  end
  $display("PASS BCD: %0d valid and %0d invalid inputs",good,bad); $finish;
 end
 initial begin #1000; $fatal(1,"timeout"); end
endmodule
